import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';
import './AdminRegister.css';

function AdminRegister() {
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    setError('');
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await axios.post('http://localhost:5000/api/admins/register', formData);
      alert(`Admin registered: ${res.data.name}`);
      navigate('/admin/login');
    } catch (err) {
      setError(err.response?.data?.error || 'Registration failed');
    }
    setLoading(false);
  };

  return (
    <form onSubmit={handleRegister} className="auth-form-container" aria-label="Admin register form" noValidate>
      <h2>Admin Register</h2>

      {error && <div className="auth-error-message" role="alert">{error}</div>}

      <input
        id="name"
        type="text"
        name="name"
        placeholder="Name"
        value={formData.name}
        onChange={handleChange}
        required
        className="auth-form-input"
        aria-required="true"
        aria-label="Admin Name"
      />

      <input
        id="email"
        type="email"
        name="email"
        placeholder="Email"
        value={formData.email}
        onChange={handleChange}
        required
        className="auth-form-input"
        aria-required="true"
        aria-label="Admin Email"
      />

      <input
        id="password"
        type="password"
        name="password"
        placeholder="Password"
        value={formData.password}
        onChange={handleChange}
        required
        className="auth-form-input"
        aria-required="true"
        aria-label="Admin Password"
      />

      <button
        type="submit"
        className="auth-submit-button"
        aria-label="Admin Register button"
        disabled={loading}
      >
        {loading ? 'Registering...' : 'Register'}
      </button>

      <Link to="/admin/login" className="auth-link" aria-label="Go to Admin Login">
        Have an account? Login
      </Link>
    </form>
  );
}

export default AdminRegister;

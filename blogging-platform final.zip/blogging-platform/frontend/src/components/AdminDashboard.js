import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './AdminDashboard.css'; // Minimalist styling

const AdminDashboard = () => {
  const [blogs, setBlogs] = useState([]);
  const [editId, setEditId] = useState(null);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');
  const token = localStorage.getItem('adminToken');

  const fetchBlogs = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/blogs', {
        headers: { 'x-auth-token': token },
      });
      setBlogs(res.data);
    } catch (err) {
      alert('Failed to fetch blogs');
      console.error(err);
    }
  };

  const deleteBlog = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/admins/blogs/${id}`, {
        headers: { 'x-auth-token': token },
      });
      fetchBlogs();
    } catch (err) {
      alert('Failed to delete blog');
      console.error(err);
    }
  };

  const startEdit = (blog) => {
    setEditId(blog._id);
    setEditTitle(blog.title);
    setEditContent(blog.content);
  };

  const cancelEdit = () => {
    setEditId(null);
    setEditTitle('');
    setEditContent('');
  };

  const saveEdit = async (id) => {
    if (!editTitle.trim() || !editContent.trim()) {
      alert('Title and content cannot be empty');
      return;
    }

    try {
      await axios.put(
        `http://localhost:5000/api/blogs/${id}/edit`,
        { title: editTitle, content: editContent },
        { headers: { 'x-auth-token': token } }
      );
      cancelEdit();
      fetchBlogs();
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.message || 'Failed to update blog');
    }
  };

  useEffect(() => {
    if (!token) {
      alert('Please login as admin first');
      return;
    }
    fetchBlogs();
  }, [token]);

  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      {blogs.length === 0 && <p>No blogs found.</p>}

      {blogs.map((blog) => (
        <div key={blog._id} className="blog-item">
          {editId === blog._id ? (
            <>
              <input
                type="text"
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                className="input"
              />
              <textarea
                value={editContent}
                onChange={(e) => setEditContent(e.target.value)}
                rows="4"
                className="textarea"
              />
              <button onClick={() => saveEdit(blog._id)} className="btn">
                Save
              </button>
              <button onClick={cancelEdit} className="btn">
                Cancel
              </button>
            </>
          ) : (
            <>
              <h3>{blog.title}</h3>
              <p>{blog.content}</p>
              <button onClick={() => startEdit(blog)} className="btn">
                Edit
              </button>
              <button onClick={() => deleteBlog(blog._id)} className="btn">
                Delete
              </button>
            </>
          )}
        </div>
      ))}
    </div>
  );
};

export default AdminDashboard;

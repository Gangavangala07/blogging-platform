import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './BlogAction.css';

function BlogAction() {
  const { blogId } = useParams();
  const navigate = useNavigate();
  const [blog, setBlog] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const token = localStorage.getItem('adminToken');

  const fetchBlog = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/blogs/${blogId}`, {
        headers: { 'x-auth-token': token },
      });
      setBlog(response.data);
      setTitle(response.data.title);
      setContent(response.data.content);
    } catch (error) {
      console.error('Error fetching blog:', error);
      alert('Failed to fetch blog. Please check your login or network.');
      if (error.response && error.response.status === 401) {
        navigate('/admin-login');
      }
    }
  };

  useEffect(() => {
    if (!token) {
      alert('Please login as admin first.');
      navigate('/admin-login');
      return;
    }
    fetchBlog();
  }, [blogId, token, navigate]);

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this blog?')) return;
    try {
      setLoading(true);
      await axios.delete(`http://localhost:5000/api/admins/blogs/${blogId}`, {
        headers: { 'x-auth-token': token },
      });
      alert('Blog deleted successfully!');
      navigate('/');
    } catch (error) {
      console.error('Error deleting blog:', error);
      alert('Failed to delete blog.');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async () => {
    if (!title.trim() || !content.trim()) {
      alert('Title and content cannot be empty');
      return;
    }
    try {
      setLoading(true);
      await axios.put(
        `http://localhost:5000/api/admins/blogs/${blogId}`,
        { title, content },
        { headers: { 'x-auth-token': token } }
      );
      alert('Blog updated successfully!');
      setEditMode(false);
      fetchBlog();
    } catch (error) {
      console.error('Error updating blog:', error);
      alert('Failed to update blog.');
    } finally {
      setLoading(false);
    }
  };

  if (!blog) return <div className="loader">Loading blog...</div>;

  return (
    <div className="blog-action-container">
      {editMode ? (
        <div>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="edit-title"
            disabled={loading}
          />
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="edit-content"
            disabled={loading}
          />
          <button onClick={handleUpdate} disabled={loading} className="save-btn">
            {loading ? 'Saving...' : 'Save Changes'}
          </button>
          <button onClick={() => setEditMode(false)} disabled={loading} className="cancel-btn">
            Cancel
          </button>
        </div>
      ) : (
        <div>
          <h2>{blog.title}</h2>
          <p>{blog.content}</p>
          <div className="action-buttons">
            <button onClick={() => setEditMode(true)} className="edit-btn" disabled={loading}>
              Edit
            </button>
            <button onClick={handleDelete} className="delete-btn" disabled={loading}>
              Delete
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default BlogAction;

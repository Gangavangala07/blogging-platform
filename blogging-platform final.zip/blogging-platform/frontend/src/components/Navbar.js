import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Navbar.css';

function Navbar() {
  const navigate = useNavigate();
  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
  const username = localStorage.getItem('username');

  const [categoriesOpen, setCategoriesOpen] = useState(false);

  const handleLogout = () => {
    localStorage.clear();
    navigate('/loginselection');
  };

  // Close dropdowns when clicking outside
  useEffect(() => {
    const closeDropdowns = () => {
      setCategoriesOpen(false);
    };
    window.addEventListener('click', closeDropdowns);
    return () => window.removeEventListener('click', closeDropdowns);
  }, []);

  // Stop propagation inside dropdown
  const stopPropagation = (e) => e.stopPropagation();

  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <Link to="/">📖 MyBlog</Link>
      </div>

      <ul className="navbar-links">
        <li><Link to="/">Home</Link></li>

        <li className="dropdown" onClick={stopPropagation}>
          <button
            onClick={() => setCategoriesOpen((prev) => !prev)}
            className="dropdown-btn"
            aria-expanded={categoriesOpen}
            aria-haspopup="true"
          >
            Categories <span className={`arrow ${categoriesOpen ? 'up' : 'down'}`}></span>
          </button>

          <div className={`dropdown-content ${categoriesOpen ? 'show' : ''}`}>
            <Link to="/category/news">📰 News</Link>
            <Link to="/category/tech">💻 Tech</Link>
            <Link to="/category/lifestyle">🌿 Lifestyle</Link>
          </div>
        </li>

        {isLoggedIn && (
          <>
              {/* fixed here */}
            <li><Link to="/profile">Profile</Link></li>
          </>
        )}

        {!isLoggedIn ? (
          <li><Link to="/loginselection">Login</Link></li>
        ) : (
          <>
            <li className="navbar-user">👤 {username}</li>
            <li>
              <button className="logout-btn" onClick={handleLogout}>
                Logout
              </button>
            </li>
          </>
        )}
      </ul>
    </nav>
  );
}

export default Navbar;

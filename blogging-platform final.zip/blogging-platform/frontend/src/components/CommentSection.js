import React, { useState } from 'react';
import './CommentSection.css';

function CommentSection() {
  const [comments, setComments] = useState([
    { id: 1, name: 'Ganga', text: 'This is a great post!' },
    { id: 2, name: 'Sravan', text: 'Very informative. Thanks!' }
  ]);
  const [newComment, setNewComment] = useState('');

  const handleAddComment = () => {
    if (newComment.trim() === '') return;
    const newEntry = {
      id: comments.length + 1,
      name: 'Anonymous',
      text: newComment
    };
    setComments([newEntry, ...comments]);
    setNewComment('');
  };

  return (
    <div className="comment-section">
      <h2>Comments</h2>

      <div className="comment-form">
        <textarea 
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          placeholder="Write your comment here..."
        ></textarea>
        <button onClick={handleAddComment}>Add Comment</button>
      </div>

      <div className="comments-list">
        {comments.map((comment) => (
          <div key={comment.id} className="comment-item">
            <div className="avatar">👤</div>
            <div>
              <h4>{comment.name}</h4>
              <p>{comment.text}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default CommentSection;

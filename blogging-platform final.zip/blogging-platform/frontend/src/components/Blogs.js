import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './Blogs.css';

const Blogs = () => {
  const [blogs, setBlogs] = useState([]);
  const [token] = useState(localStorage.getItem('token') || null);
  const [comments, setComments] = useState({});

  // Fetch blogs from backend
  const fetchBlogs = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/blogs');
      // If you still want to sort pinned blogs on top (if backend sends them with isPinned property)
      const sortedBlogs = res.data.sort((a, b) => {
        if (a.isPinned === b.isPinned) return 0;
        return a.isPinned ? -1 : 1;
      });
      setBlogs(sortedBlogs);
    } catch (err) {
      console.error('Error fetching blogs:', err);
      alert('Failed to fetch blogs');
    }
  };

  useEffect(() => {
    fetchBlogs();
  }, []);

  // Handle like a blog post
  const handleLike = async (id) => {
    if (!token) return alert('Please log in to like blogs.');

    try {
      await axios.post(
        `http://localhost:5000/api/blogs/${id}/like`,
        {},
        { headers: { 'x-auth-token': token } }
      );
      fetchBlogs();
    } catch (err) {
      console.error('Like failed:', err.response?.data || err.message);
      alert('Failed to like blog');
    }
  };

  // Handle adding a comment
  const handleAddComment = async (blogId) => {
    if (!token) {
      alert('Please log in to comment.');
      return;
    }

    const commentText = comments[blogId];
    if (!commentText || commentText.trim() === '') return;

    try {
      await axios.post(
        `http://localhost:5000/api/blogs/${blogId}/comment`,
        { text: commentText.trim() },
        { headers: { 'x-auth-token': token } }
      );
      setComments({ ...comments, [blogId]: '' });
      fetchBlogs();
    } catch (err) {
      console.error('Comment failed:', err.response?.data || err.message);
      alert('Failed to add comment');
    }
  };

  return (
    <div className="blogs-container">
      <h1 className="blogs-header">Blogs</h1>
      <Link to="/create" className="create-blog-link">Create Blog</Link>

      {blogs.length === 0 && <p>No blogs to display.</p>}

      {blogs.map((blog) => {
        const likesCount = Array.isArray(blog.likes) ? blog.likes.length : 0;

        return (
          <div
            key={blog._id}
            className="blog-item"
          >
            <h3 className="blog-title">{blog.title}</h3>
            <p className="blog-content">{blog.content}</p>
            <p className="blog-author"><strong>By:</strong> {blog.userName || 'Unknown User'}</p>
            <p className="blog-likes"><strong>Likes:</strong> {likesCount}</p>

            <div className="blog-buttons">
              <button
                onClick={() => handleLike(blog._id)}
                className="blog-like-button"
                disabled={!token}
                title={!token ? 'Login to like' : ''}
              >
                Like
              </button>

              <input
                type="text"
                placeholder="Add a comment..."
                value={comments[blog._id] || ''}
                onChange={(e) => setComments({ ...comments, [blog._id]: e.target.value })}
                className="comment-input"
              />

              <button
                onClick={() => handleAddComment(blog._id)}
                className="blog-comment-button"
                disabled={!token || !(comments[blog._id]?.trim())}
                title={!token ? 'Login to comment' : ''}
              >
                Comment
              </button>
            </div>

            <div className="comments-section">
              <strong>Comments:</strong>
              <ul className="comments-list">
                {blog.comments && blog.comments.length > 0 ? (
                  blog.comments.map((c, i) => (
                    <li key={c._id || i}>
                      {c.text} - <em>{c.userName || 'Anonymous'}</em>
                    </li>
                  ))
                ) : (
                  <li>No comments yet</li>
                )}
              </ul>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default Blogs;

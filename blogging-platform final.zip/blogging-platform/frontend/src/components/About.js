import React from 'react';
import './style.css';

function About() {
  return (
    <div className="page-container">
      <h1 className="page-title">📝 About This Blog</h1>
      <p className="page-text">
        Welcome to my personal blog — a space where I share thoughts on tech, travel, food, and everything in between.
      </p>
      <p className="page-text">
        I'm passionate about writing, and this platform is my creative corner on the internet.
        Whether it's coding tutorials, personal stories, or photography tips — you'll find it all here.
      </p>
      <p className="page-text">
        Thanks for stopping by. Stick around and enjoy reading!
      </p>
    </div>
  );
}

export default About;

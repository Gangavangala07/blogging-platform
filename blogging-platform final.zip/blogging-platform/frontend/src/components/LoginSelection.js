import React from 'react';
import { useNavigate } from 'react-router-dom';
import './LoginSelection.css';

function LoginSelection() {
  const navigate = useNavigate();

  return (
    <div className="login-selection-container">
      <h2>Select Role to Login</h2>
      <div className="buttons">
        <button onClick={() => navigate('/login')}>User Login</button>
        <button onClick={() => navigate('/admin/login')}>Admin Login</button>
      </div>
    </div>
  );
}

export default LoginSelection;

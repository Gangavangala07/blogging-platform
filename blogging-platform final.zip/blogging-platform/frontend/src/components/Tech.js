import React, { useState } from 'react';

function Tech() {
  const dummyTech = [
    {
      id: 1,
      title: "Quantum Computing: What’s Next?",
      date: "May 19, 2025",
      excerpt: "Quantum processors are poised to tackle real-world problems, beyond labs.",
      content: `Tech giants like IBM and Google are racing to achieve quantum supremacy, focusing on real-world applications like drug discovery, financial modeling, and weather prediction. Experts forecast mainstream enterprise adoption within a decade.`
    },
    {
      id: 2,
      title: "The Rise of AR Glasses",
      date: "May 16, 2025",
      excerpt: "Augmented Reality glasses set to redefine digital experiences.",
      content: `Next-gen AR glasses promise immersive navigation, real-time translations, and advanced gaming overlays. With lightweight, stylish designs and increased affordability, analysts predict a boom in consumer demand by late 2025.`
    },
  ];

  const [expandedIds, setExpandedIds] = useState([]);

  const toggleExpand = (id) => {
    if (expandedIds.includes(id)) {
      setExpandedIds(expandedIds.filter(expandedId => expandedId !== id));
    } else {
      setExpandedIds([...expandedIds, id]);
    }
  };

  return (
    <>
      <style>{`
        .app-container {
          max-width: 800px;
          margin: 40px auto;
          padding: 25px;
          background: #e0f7fa;
          border-radius: 20px;
          box-shadow: 0 8px 20px rgba(0, 150, 136, 0.3);
          font-family: 'Poppins', sans-serif;
          color: #222;
        }
        .page-title {
          font-size: 2.8rem;
          color: #006064;
          margin-bottom: 10px;
          text-align: center;
          font-weight: 700;
        }
        p {
          font-size: 1.15rem;
          margin-bottom: 30px;
          text-align: center;
          color: #4e4e4e;
        }
        .news-list {
          display: flex;
          flex-direction: column;
          gap: 30px;
        }
        .news-item {
          background: white;
          border-radius: 15px;
          padding: 20px 25px;
          box-shadow: 0 4px 15px rgba(0, 96, 100, 0.15);
          transition: transform 0.3s ease;
        }
        .news-item:hover {
          transform: translateY(-5px);
          box-shadow: 0 10px 30px rgba(0, 96, 100, 0.3);
        }
        .news-item h2 {
          color: #00796b;
          margin-bottom: 5px;
          font-weight: 700;
        }
        .news-item small {
          display: block;
          color: #78909c;
          margin-bottom: 15px;
          font-style: italic;
          font-weight: 500;
        }
        .news-item p {
          font-size: 1rem;
          line-height: 1.5;
          color: #37474f;
        }
        .news-full-content {
          white-space: pre-wrap;
          background-color: #e0f2f1;
          padding: 15px 18px;
          border-radius: 10px;
          margin-top: 15px;
          font-family: 'Courier New', Courier, monospace;
          font-size: 0.95rem;
          color: #004d40;
          line-height: 1.6;
        }
        .read-more-btn {
          margin-top: 18px;
          background-color: #00796b;
          color: white;
          border: none;
          padding: 10px 18px;
          border-radius: 12px;
          cursor: pointer;
          font-weight: 600;
          font-size: 1rem;
          transition: background-color 0.3s ease;
        }
        .read-more-btn:hover {
          background-color: #004d40;
        }
      `}</style>

      <div className="app-container">
        <h1 className="page-title">💻 Tech Updates</h1>
        <p>Explore the latest trends in technology, gadgets, and digital innovation.</p>

        <div className="news-list">
          {dummyTech.map(item => (
            <div key={item.id} className="news-item">
              <h2>{item.title}</h2>
              <small>{item.date}</small>
              <p>{item.excerpt}</p>

              {expandedIds.includes(item.id) && (
                <pre className="news-full-content">{item.content}</pre>
              )}

              <button
                className="read-more-btn"
                onClick={() => toggleExpand(item.id)}
              >
                {expandedIds.includes(item.id) ? 'Show Less' : 'Read More'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default Tech;

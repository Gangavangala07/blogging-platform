import React, { useState } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';
import { useNavigate, Link } from 'react-router-dom';
import './AdminLogin.css';


const AdminLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      if (!email || !password) {
        setErrorMsg('Please enter email and password.');
        return;
      }
      const res = await axios.post('http://localhost:5000/api/admins/login', { email, password });
      localStorage.setItem('adminToken', res.data.token);
      Swal.fire({
  title: 'Login Successful!',
  icon: 'success',   // fixed here
  confirmButtonText: 'OK',
  confirmButtonColor: '#00796b',
});

      navigate('/admin/dashboard');
    } catch (error) {
      setErrorMsg(error.response?.data?.message || 'Admin login failed.');
    }
  };

  return (
    <div className="auth-form-container" aria-label="Admin login form">
      <h2>Admin Login</h2>
      {errorMsg && <div className="auth-error-message" role="alert">{errorMsg}</div>}
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="auth-form-input"
        aria-label="Admin Email"
        autoComplete="username"
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="auth-form-input"
        aria-label="Admin Password"
        autoComplete="current-password"
      />
      <button onClick={handleLogin} className="auth-submit-button" aria-label="Admin Login button">
        Login
      </button>
      <Link to="/admin/register" className="auth-link" aria-label="Go to Admin Register">
        Don't have an account? Register
      </Link>
    </div>
  );
};

export default AdminLogin;

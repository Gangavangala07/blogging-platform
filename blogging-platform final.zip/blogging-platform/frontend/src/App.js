import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import "./App.css";

import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Blogs from './components/Blogs';
import Profile from './components/Profile';
import CreateBlog from './components/CreateBlog';
import LoginSelection from './components/LoginSelection';
import Login from './components/Login';
import Register from './components/Register';
import AdminRegister from './components/AdminRegister';
import AdminLogin from './components/AdminLogin';
import AdminDashboard from './components/AdminDashboard';
import CommentSection from './components/CommentSection';
import News from './components/News';
import Tech from './components/Tech';
import Lifestyle from './components/Lifestyle';
import About from './components/About';
import Contact from './components/Contact';

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <div style={{ paddingTop: '70px', minHeight: 'calc(100vh - 140px)' }}>
        <Routes>
          <Route path="/" element={<Blogs />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/create" element={<CreateBlog />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/loginselection" element={<LoginSelection />} />

          {/* Admin routes */}
          <Route path="/admin/register" element={<AdminRegister />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />

          {/* Category routes */}
          <Route path="/category/news" element={<News />} />
          <Route path="/category/tech" element={<Tech />} />
          <Route path="/category/lifestyle" element={<Lifestyle />} />

          {/* Comments */}
          <Route path="/comments" element={<CommentSection />} />

          {/* About & Contact */}
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </div>
      <Footer />
    </BrowserRouter>
  );
}

export default App;
